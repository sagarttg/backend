const extractQA = (text) => {
  const sentences = text.split(/[.?!]/).map(s => s.trim());

  let question = "";
  let answer = "";

  for (let i = sentences.length - 1; i >= 0; i--) {
    const s = sentences[i];

    if (!question && s.includes("?")) {
      question = s;
      continue;
    }

    if (question && s) {
      answer = s;
      break;
    }
  }

  return { question, answer };
};

module.exports = { extractQA };